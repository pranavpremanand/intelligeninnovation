<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet" crossorigin="anonymous">
    <title>Badge</title>
    <style>
        body{
            display: flex;
            justify-content: center;
        }
        * {
            font-family: 'Inter', sans-serif;
        }
        .badge-container {
            width: 300px;
            height: 500px;
            background: linear-gradient(to bottom, #020A33 0%, #304CDD 100%);
            display: flex;
            flex-direction: column;
            align-items: center;
            overflow: hidden; /* Ensure no overflow */
        }
        .badge-container h1 {
            font-size: 18px;
            color: white;
            font-weight: bold;
            margin-top: 20px;
        }
        .badge-container img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin-top: 20px;
            margin-bottom: 20px;
            object-fit: cover;
        }
        .badge-container p.name {
            font-size: 16px;
            font-weight: bold;
            color: white;
            margin: 10px 0px;
        }
        .badge-container p.email,
        .badge-container p.address {
            font-size: 13px;
            color: white;
            width: 100%;
            text-align: center;
            margin: 5px 0px;
        }
        .badge-container .qr-code {
            margin-top: 40px;
            background: transparent;
            position: relative;
        }
        
        .corner-border {
            position: absolute;
            border: 4px solid #000000; /* Border color and size */
            width: 30px; /* Size of the corner border */
            height: 30px;
            background: transparent;
        }
        .corner-border.tl {
            top: -17px;
            left: -17px;
            border-top: 4px solid white;
            border-left: 4px solid white;
            border-right: 0px;
            border-bottom: 0px;
        }
        .corner-border.tr {
            top: -17px;
            right: -17px;
            border-top: 4px solid white;
            border-right: 4px solid white;
            border-left: 0px;
            border-bottom: 0px;
        }
        .corner-border.bl {
            bottom: -17px;
            left: -17px;
            border-bottom: 4px solid white;
            border-left: 4px solid white;
            border-right: 0px;
            border-top: 0px;
        }
        .corner-border.br {
            bottom: -17px;
            right: -17px;
            border-bottom: 4px solid white;
            border-right: 4px solid white;
            border-left: 0px;
            border-top: 0px;
        }
    </style>
</head>
<body>
<div class="badge-container" id="badge-container">
    <h1>Magical Boo Bash</h1>
    <?php if($customer->imageUrl!="" && $customer->imageUrl!=null): ?>
        <img src="<?php echo e($customer->imageUrl); ?>" alt="User" />
    <?php else: ?>
    <img src="/images/placeholder.png" alt="User" />
    <?php endif; ?>
    <p class="name"><?php echo e($customer->name); ?></p>
    <p class="email"><?php echo e($customer->email); ?></p>
    <p class="address"><?php echo e($customer->address); ?></p>
    <div class="qr-code">
        <?php 
        $qr_code = "https://boobash.com/$customer->uniqueId";
        $hex = "#ffffff";
        list($r, $g, $b) = sscanf($hex, "#%02x%02x%02x");
        ?>
        <?php echo QrCode::size(140)->color($r, $g, $b)->backgroundColor(0,0,0,0)->generate($qr_code); ?>


        <div class="corner-border tl"></div>
    <div class="corner-border tr"></div>
    <div class="corner-border bl"></div>
    <div class="corner-border br"></div>
    </div>

</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdn.bootcss.com/FileSaver.js/2.0.5/FileSaver.min.js"></script>
<script src="https://cdn.bootcss.com/dom-to-image/2.6.0/dom-to-image.min.js"></script>
<script>
window.onload = function() {
    var node = document.getElementById('badge-container');
    
    var options = {
        width: node.offsetWidth * 2,  // Double the width for higher resolution
        height: node.offsetHeight * 2,  // Double the height for higher resolution
        style: {
            transform: 'scale(2)',  // Double the scale for higher resolution
            transformOrigin: 'top center',  // Set transform origin
            // overflow: 'hidden' // Ensure content stays within bounds
        },
        quality: 1  // Set quality to maximum (range: 0-1)
    };

    domtoimage.toBlob(node, options)
        .then(function(blob) {
            saveAs(blob, 'badge.png');  // Use saveAs from FileSaver.js
            window.setTimeout(function() {
                window.close();
            }, 1000); // Delay to ensure the download starts
        })
        .catch(function(error) {
            console.error('Oops, something went wrong!', error);
        });
};
</script>
</body>
</html>
<?php /**PATH /Applications/Laravel Projects/magic-boobash-apis/resources/views/badge.blade.php ENDPATH**/ ?>