
<!DOCTYPE html>
<html class="no-js" lang="zxx" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Harzeno - Website Landing Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Technology IT Solutions HTML Template">
    <!-- Favicon -->
    <link rel="icon" href="/web-dev/assets/images/fav.png">

    <!-- CSS
        ============================================ -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <!-- Font Family CSS -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Vendor & Plugins CSS (Please remove the comment from below vendor.min.css & plugins.min.css for better website load performance and remove css files from avobe) -->

    <link rel="stylesheet" href="/web-dev/assets/css/vendor/vendor.min.css">
    <link rel="stylesheet" href="/web-dev/assets/css/plugins/plugins.min.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="/web-dev/assets/css/style.css">
 <style>
    .navigation-menu--text_white > ul > li > a:before {
    background-color: #7b3792;
}
.navigation-menu--text_white > ul > li > a:before {
    background-color: #ffffff;
}
 </style>
</head>

<body>

    <div class="preloader-activate preloader-active open_tm_preloader">
        <div class="preloader-area-wrap">
            <div class="spinner d-flex justify-content-center align-items-center h-100">
                <div class="bounce1"></div>
                <div class="bounce2"></div>
                <div class="bounce3"></div>
            </div>
        </div>
    </div>



    <!--====================  header area ====================-->
    <div class="header-area header-sticky only-mobile-sticky">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="header position-relative">
                        <!-- brand logo -->
                        <div class="header__logo top-logo">
                            <a href="index.html">
                                <img src="/web-dev/assets/images/logo/hLogo.png" width="160" height="48" aria-label="Harzeno Logo" class="img-fluid" alt="">
                            </a>
                        </div>

                        <div class="header-right flexible-image-slider-wrap">

                            <div class="header-right-inner" id="hidden-icon-wrapper">
                                <!-- Header Search Form -->

                                <!-- Header Top Info -->
                                <div class="swiper-container header-top-info-slider-werap top-info-slider__container">
                                    <div class="swiper-wrapper header-top-info-inner default-color">
                                        <div class="swiper-slide">
                                            <div class="info-item">
                                                <div class="info-icon">
                                                    <span class="fa fa-phone"></span>
                                                </div>
                                                <div class="info-content">
                                                    <h6 class="info-title">0122 8899900</h6>
                                                    <div class="info-sub-title">Info@example.com</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="info-item">
                                                <div class="info-icon">
                                                    <span class="fa fa-map-marker-alt"></span>
                                                </div>
                                                <div class="info-content">
                                                    <h6 class="info-title">219 Amara Fort Apt. 394</h6>
                                                    <div class="info-sub-title">New York, NY 941</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="info-item">
                                                <div class="info-icon">
                                                    <span class="fa fa-clock"></span>
                                                </div>
                                                <div class="info-content">
                                                    <h6 class="info-title">8:00AM - 6:00PM</h6>
                                                    <div class="info-sub-title">Monday to Saturday</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="info-item">
                                                <div class="info-icon">
                                                    <span class="fas fa-comment-alt"></span>
                                                </div>
                                                <div class="info-content">
                                                    <h6 class="info-title">Online 24/7</h6>
                                                    <div class="info-sub-title">+122 123 4567</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Header Social Networks -->
                                <div class="header-social-networks style-icons">
                                    <div class="inner">
                                        <a class=" social-link hint--black hint--bottom-left" aria-label="Twitter" href="https://twitter.com" data-hover="Twitter" target="_blank">
                                            <i class="social-icon fab fa-twitter"></i>
                                        </a>
                                        <a class=" social-link hint--black hint--bottom-left" aria-label="Facebook" href="https://facebook.com" data-hover="Facebook" target="_blank">
                                            <i class="social-icon fab fa-facebook-f"></i>
                                        </a>
                                        <a class=" social-link hint--black hint--bottom-left" aria-label="Instagram" href="https://instagram.com" data-hover="Instagram" target="_blank">
                                            <i class="social-icon fab fa-instagram"></i>
                                        </a>
                                        <a class=" social-link hint--black hint--bottom-left" aria-label="Linkedin" href="https://linkedin.com" data-hover="Linkedin" target="_blank">
                                            <i class="social-icon fab fa-linkedin"></i>
                                        </a>
                                    </div>
                                </div>

                            </div>
                            <!-- mobile menu -->
                            <div class="mobile-navigation-icon d-block d-xl-none" id="mobile-menu-trigger">
                                <i></i>
                            </div>
                            <!-- hidden icons menu -->
                            <div class="hidden-icons-menu d-block d-md-none" id="hidden-icon-trigger">
                                <a href="javascript:void(0)">
                                    <i class="far fa-ellipsis-h-alt"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="header-bottom-wrap bg-theme-default d-md-block d-none header-sticky">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header-bottom-inner position-relative">
                            <div class="header-bottom-left-wrap">
                                <!-- navigation menu -->
                                <div class="header__navigation d-none d-xl-block">
                                    <nav class="navigation-menu navigation-menu--text_white">

                                        <ul>
                                            <li>
                                                <a href="#home"><span>Home</span></a>
                                            </li>
                                            <li>
                                                <a href="#aboutus"><span>About Us</span></a>
                                            </li>
                                            <li>
                                                <a href="#portfolio"><span>Portfolio</span></a>
                                            </li>
                                            <li>
                                                <a href="#ourteam"><span>Our Team</span></a>
                                            </li>
                                            <li>
                                                <a href="#pricing"><span>Our Pricing</span></a>
                                            </li>
                                            <li>
                                                <a href="#testimoninal"><span>Testimonials</span></a>
                                            </li>
                                            <li>
                                                <a href="#contactus"><span>Contact Us</span></a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>

                      
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!--====================  End of header area  ====================-->













    <div id="main-wrapper">
        <div class="site-wrapper-reveal">
            <!--============ Appointment Hero Start ============-->
            <div class="appointment-hero-wrapper appointment-hero-bg section-space--ptb_120" id="home">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-6">
                            <div class="appointment-hero-wrap wow move-up">
                                <div class="appointment-hero-text">
                                    <h6 class="text-white">Secure & IT Services </h6>
                                    <h1 class="font-weight--reguler text-white mb-30">Excellent IT services for <span class="text-line">your success</span></h1>
                                 
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5 me-auto ms-auto col-md-6">
                            <div class="business-solution-form-wrap me-auto ms-auto">
                                <div class="contact-title text-center section-space--mb_40">
                                    <h5 class="mb-10">Book appointment</h5>
                                    <p class="text">It's out pleasure to have a chance to cooperate.</p>
                                </div>
                                <form id="contact-form" action="/Harzeno/submit-form" method="post">
                                    <!-- <form id="contact-form" action="https://whizthemes.com/mail-php/jowel/Harzeno/php/hero-mail.php" method="post"> -->
                                        <?php echo csrf_field(); ?>
                                    <div class="contact-form__two">
                                    <div class="contact-inner">
                                        <input name="type" type="hidden" value="web_dev">
                                    </div>
                                        <div class="contact-inner">
                                            <input name="con_name" type="text" placeholder="Name *" required>
                                        </div>
                                        <div class="contact-inner">
                                            <input name="con_email" type="email" placeholder="Email *" required>
                                        </div>
                                        <div class="contact-inner">
                                            <input name="con_phone" type="text" placeholder="Phone Number *" required>
                                        </div>
                                        <div class="contact-inner contact-message">
                                            <textarea name="con_message" placeholder="Please describe what you need." required></textarea>
                                        </div>
                                        <div class="comment-submit-btn text-center">
                                            <button class="ht-btn ht-btn-md" type="submit">Submit</button>
                                            <p class="form-messege"></p>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--============ Appointment Hero End ============-->
   <!--=========== About Company Area Start ==========-->
   <div class="software-innovation-about-company-area software-innovation-about-bg section-space--ptb_120" id="aboutus">
    <div class="container">

        <div class="row">

            <div class="col-lg-6">
                <div class="image-inner-video-section">
                    <img class="img-fluid border-radus-5" src="/web-dev/assets/images/banners/final3.png" alt="">
                </div>
            </div>
            <div class="col-lg-6 ms-auto mt-30">
                <div class="machine-learning-about-content">
                    <div class="section-title mb-20">
                        <!-- section-title-wrap Start -->
                        <div class="section-title-wrap text-left section-space--mb_30">
                            <h6 class="section-sub-title mb-20">INDUSTRIES WE SERVE</h6>
                            <h3 class="heading">For your very specific industry, we <span class="text-color-primary">have highly-tailored IT solutions.</span>
                            </h3>
                        </div>
                        <!-- section-title-wrap Start -->

                        <p class="dec-text mt-20">Engitech is the partner of choice for many of the world’s leading enterprises, SMEs and technology challengers. We help businesses elevate their value through custom software development, product design, QA and consultancy services.</p>
                        <div class="button-box mt-5">
                            <div class="hero-button">
                              
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 
<!--=========== About Company Area End ==========-->
     <!--===========  Projects wrapper Start =============-->
     <div class="projects-wrapper section-space--pb_70 section-space--pt_100 projects-masonary-wrapper" id="portfolio">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-wrap text-center section-space--mb_40">
                        <h3 class="heading">Our projects<span class="text-color-primary"> make us proud</span></h3>
                    </div>

                    <div class="messonry-button text-center  section-space--mb_60">
                        <button data-filter="*" class="is-checked"><span class="filter-text">All</span><span class="filter-counter">6</span></button>
                        <button data-filter=".cat--1"><span class="filter-text">Custom Software Development</span> <span class="filter-counter">1</span></button>
                        <button data-filter=".cat--2"><span class="filter-text">Mobile App Development</span> <span class="filter-counter">3</span></button>
                        <button data-filter=".cat--3"><span class="filter-text">Website Development</span> <span class="filter-counter">1</span></button>
                        <button data-filter=".cat--4"><span class="filter-text">AI Development</span> <span class="filter-counter">1</span></button>
                        <button data-filter=".cat--5"><span class="filter-text">AI Chatbot Development</span> <span class="filter-counter">1</span></button>
                        <button data-filter=".cat--6"><span class="filter-text">Game Development</span> <span class="filter-counter">1</span></button>
                        <button data-filter=".cat--7"><span class="filter-text">Robotic Process Automation (RPA)</span> <span class="filter-counter">1</span></button>
                    </div>
                </div>
            </div>

            <div class="projects-case-wrap">
                <div class="row mesonry-list">

                    <!--<div class="resizer"></div>-->
                    <div class="col-lg-4 col-md-6 cat--1">
                        <!-- Projects Wrap Start -->
                        <a href="#" class="projects-wrap style-2">
                            <div class="projects-image-box">
                                <div class="projects-image">
                                    <img class="img-fluid" src="/web-dev/assets/images/projects/case-study-01-480x298.webp" alt="">
                                </div>
                                <div class="content">
                                    <div class="post-categories">Cyber Security</div>
                                    <h6 class="heading">Harzeno-Smart Vision</h6>
                                </div>
                            </div>
                        </a>
                        <!-- Projects Wrap End -->
                    </div>

                    <div class="col-lg-4 col-md-6 cat--2 ">
                        <!-- Projects Wrap Start -->
                        <a href="#" class="projects-wrap style-2">
                            <div class="projects-image-box">
                                <div class="projects-image">
                                    <img class="img-fluid" src="/web-dev/assets/images/projects/case-study-02-480x298.webp" alt="">
                                </div>
                                <div class="content">
                                    <div class="post-categories">Cyber Security</div>
                                    <h6 class="heading">Arden-Internal Networking</h6>
                                </div>
                            </div>
                        </a>
                        <!-- Projects Wrap End -->
                    </div>

                    <div class="col-lg-4 col-md-6 cat--3">
                        <!-- Projects Wrap Start -->
                        <a href="#" class="projects-wrap style-2">
                            <div class="projects-image-box">
                                <div class="projects-image">
                                    <img class="img-fluid" src="/web-dev/assets/images/projects/case-study-03-480x298.webp" alt="">
                                </div>
                                <div class="content">
                                    <div class="post-categories">Cyber Security</div>
                                    <h6 class="heading">A Freeserve case study</h6>
                                </div>
                            </div>
                        </a>
                        <!-- Projects Wrap End -->
                    </div>

                    <div class="col-lg-4 col-md-6 cat--4">
                        <!-- Projects Wrap Start -->
                        <a href="#" class="projects-wrap style-2">
                            <div class="projects-image-box">
                                <div class="projects-image">
                                    <img class="img-fluid" src="/web-dev/assets/images/projects/case-study-04-480x298.webp" alt="">
                                </div>
                                <div class="content">
                                    <div class="post-categories">Cyber Security</div>
                                    <h6 class="heading">Aqua – Research and Energy</h6>
                                </div>
                            </div>
                        </a>
                        <!-- Projects Wrap End -->
                    </div>

                    <div class="col-lg-4 col-md-6 cat--5">
                        <!-- Projects Wrap Start -->
                        <a href="#" class="projects-wrap style-2">
                            <div class="projects-image-box">
                                <div class="projects-image">
                                    <img class="img-fluid" src="/web-dev/assets/images/projects/case-study-05-480x298.webp" alt="">
                                </div>
                                <div class="content">
                                    <div class="post-categories">IT consultancy</div>
                                    <h6 class="heading">A Sixbase typical case study</h6>
                                </div>
                            </div>
                        </a>
                        <!-- Projects Wrap End -->
                    </div>

                    <div class="col-lg-4 col-md-6 cat--6">
                        <!-- Projects Wrap Start -->
                        <a href="#" class="projects-wrap style-2">
                            <div class="projects-image-box">
                                <div class="projects-image">
                                    <img class="img-fluid" src="/web-dev/assets/images/projects/case-study-06-480x298.webp" alt="">
                                </div>
                                <div class="content">
                                    <div class="post-categories">IT Security</div>
                                    <h6 class="heading">Healsoul – Technology & Health</h6>
                                </div>
                            </div>
                        </a>
                        <!-- Projects Wrap End -->
                    </div>

                    <div class="col-lg-4 col-md-6 cat--7">
                        <!-- Projects Wrap Start -->
                        <a href="#" class="projects-wrap style-2">
                            <div class="projects-image-box">
                                <div class="projects-image">
                                    <img class="img-fluid" src="/web-dev/assets/images/projects/case-study-06-480x298.webp" alt="">
                                </div>
                                <div class="content">
                                    <div class="post-categories">IT Security</div>
                                    <h6 class="heading">Healsoul – Technology & Health</h6>
                                </div>
                            </div>
                        </a>
                        <!-- Projects Wrap End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--===========  Projects wrapper End =============-->

            <!-- ============ Team Member Wrapper Start =============== -->
            <div class="team-member-wrapper section-space--pt_100 section-space--pb_40" id="ourteam">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="section-title section-space--mb_60">
                                <h3 class="heading">Our <span class="text-color-primary">experience </span> experts</h3>
                                <p class="text mt-30">Harzeno specializes in technological and IT-related services such as product engineering, warranty management, building cloud, infrastructure, network, etc. </p>

                                <div class="sider-title-button-box mt-30">
                                    <a href="#" class="ht-btn ht-btn-md">Join us now</a>
                                    <a href="#" class="btn-text font-weight--bold small-mt__20">View all team <i class="ml-1 button-icon fas fa-arrow-right"></i></a>
                                </div>

                            </div>
                        </div>
                        <div class="col-lg-8 ht-team-member-style-one">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 wow move-up">
                                    <div class="grid-item">
                                        <div class="ht-team-member">
                                            <div class="team-image">
                                                <img class="img-fluid" src="/web-dev/assets/images/team/team-member-01-370x250.webp" alt="">
                                                <div class="social-networks">
                                                    <div class="inner">
                                                        <a target="_blank" href="#" class=" hint--bounce  hint--top hint--theme-two" aria-label="Facebook"><i class="fab fa-facebook"></i>
                                                        </a>
                                                        <a target="_blank" href="#" class=" hint--bounce hint--top hint--theme-two" aria-label="Twitter"><i class="fab fa-twitter"></i>
                                                        </a>
                                                        <a target="_blank" href="#" class=" hint--bounce hint--top hint--theme-two" aria-label="Instagram"><i class="fab fa-instagram"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="team-info ">
                                                <h5 class="name">Dollie Horton </h5>
                                                <div class="position">Marketing</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 wow move-up">
                                    <div class="grid-item">
                                        <div class="ht-team-member">
                                            <div class="team-image">
                                                <img class="img-fluid" src="/web-dev/assets/images/team/team-member-07-370x250.webp" alt="">
                                                <div class="social-networks">
                                                    <div class="inner">
                                                        <a target="_blank" href="#" class=" hint--bounce  hint--top hint--theme-two" aria-label="Facebook"><i class="fab fa-facebook"></i>
                                                        </a>
                                                        <a target="_blank" href="#" class=" hint--bounce hint--top hint--theme-two" aria-label="Twitter"><i class="fab fa-twitter"></i>
                                                        </a>
                                                        <a target="_blank" href="#" class=" hint--bounce hint--top hint--theme-two" aria-label="Instagram"><i class="fab fa-instagram"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="team-info ">
                                                <h5 class="name">Stephen Mearsley </h5>
                                                <div class="position">President & CEO</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 wow move-up">
                                    <div class="grid-item">
                                        <div class="ht-team-member">
                                            <div class="team-image">
                                                <img class="img-fluid" src="/web-dev/assets/images/team/team-member-04-370x250.webp" alt="">
                                                <div class="social-networks">
                                                    <div class="inner">
                                                        <a target="_blank" href="#" class=" hint--bounce  hint--top hint--theme-two" aria-label="Facebook"><i class="fab fa-facebook"></i>
                                                        </a>
                                                        <a target="_blank" href="#" class=" hint--bounce hint--top hint--theme-two" aria-label="Twitter"><i class="fab fa-twitter"></i>
                                                        </a>
                                                        <a target="_blank" href="#" class=" hint--bounce hint--top hint--theme-two" aria-label="Instagram"><i class="fab fa-instagram"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="team-info ">
                                                <h5 class="name">Maggie Strickland </h5>
                                                <div class="position">Financial Services</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 wow move-up">
                                    <div class="grid-item">
                                        <div class="ht-team-member">
                                            <div class="team-image">
                                                <img class="img-fluid" src="/web-dev/assets/images/team/team-member-02-370x250.webp" alt="">
                                                <div class="social-networks">
                                                    <div class="inner">
                                                        <a target="_blank" href="#" class=" hint--bounce  hint--top hint--theme-two" aria-label="Facebook"><i class="fab fa-facebook"></i>
                                                        </a>
                                                        <a target="_blank" href="#" class=" hint--bounce hint--top hint--theme-two" aria-label="Twitter"><i class="fab fa-twitter"></i>
                                                        </a>
                                                        <a target="_blank" href="#" class=" hint--bounce hint--top hint--theme-two" aria-label="Instagram"><i class="fab fa-instagram"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="team-info ">
                                                <h5 class="name">Monica Blews</h5>
                                                <div class="position">Project manager</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============ Team Member Wrapper End =============== -->



            <!--===========  Projects wrapper Start =============-->
                       <!--========= Pricing Table Area Start ==========-->
                       <div class="pricing-table-area section-space--ptb_100 bg-gray" id="pricing">
                        <div class="pricing-table-title-area position-relative">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="section-title-wrapper text-center section-space--mb_40 wow move-up">
                                            <h3 class="section-title">Affordable price plans<span class="text-color-primary"> for you!</span> </h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pricing-table-content-area">
                            <div class="container">
        
                                <div class="row">
                                    <div class="col-12 text-center wow move-up">
                                        <ul class="nav justify-content-center ht-plans-menu  section-space--mb_60" role="tablist">
                                            <li class="tab__item nav-item active">
                                                <a class="nav-link active" data-bs-toggle="tab" href="#month-tab" role="tab" aria-selected="true">Per month</a>
                                            </li>
                                            <li class="tab__item nav-item ">
                                                <a class="nav-link" data-bs-toggle="tab" href="#year-tab" role="tab" aria-selected="false">Per year</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
        
                                <div class="tab-content ht-tab__content wow move-up">
                                    <div class="tab-pane fade show active" id="month-tab" role="tabpanel">
                                        <div class="row pricing-table-one">
                                            <div class="col-12 col-md-6 col-lg-4 col-xl-4 pricing-table">
                                                <div class="pricing-table__inner">
                                                    <div class="pricing-table__header">
                                                        <h6 class="sub-title">Basic</h6>
                                                        <div class="pricing-table__image">
                                                            <img src="/web-dev/assets/images/icons/mitech-pricing-box-icon-01-90x90.webp" class="img-fluid" alt="">
                                                        </div>
                                                        <div class="pricing-table__price-wrap">
                                                            <h6 class="currency">$</h6>
                                                            <h6 class="price">19</h6>
                                                            <h6 class="period">/mo</h6>
                                                        </div>
                                                    </div>
                                                    <div class="pricing-table__body">
                                                        <div class="pricing-table__footer">
                                                            <a href="#" class="ht-btn ht-btn-md ht-btn--outline">Get started</a>
                                                        </div>
                                                        <ul class="pricing-table__list text-left">
                                                            <li>03 projects</li>
                                                            <li>Quality &amp; Customer Experience</li>
                                                            <li><span class="featured">Try for free, forever!</span></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6 col-lg-4 col-xl-4 pricing-table pricing-table--popular">
                                                <div class="pricing-table__inner">
                                                    <div class="pricing-table__feature-mark">
                                                        <span>Popular Choice</span>
                                                    </div>
                                                    <div class="pricing-table__header">
                                                        <h6 class="sub-title">Professional</h6>
                                                        <div class="pricing-table__image">
                                                            <img src="/web-dev/assets/images/icons/mitech-pricing-box-icon-02-88x88.webp" class="img-fluid" alt="">
                                                        </div>
                                                        <div class="pricing-table__price-wrap">
                                                            <h6 class="currency">$</h6>
                                                            <h6 class="price">59</h6>
                                                            <h6 class="period">/mo</h6>
                                                        </div>
                                                    </div>
                                                    <div class="pricing-table__body">
                                                        <div class="pricing-table__footer">
                                                            <a href="#" class="ht-btn  ht-btn-md ">Get started</a>
                                                        </div>
                                                        <ul class="pricing-table__list text-left">
                                                            <li>Unlimited project</li>
                                                            <li>Power And Predictive Dialing</li>
                                                            <li>Quality &amp; Customer Experience</li>
                                                            <li>24/7 phone and email support</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6 col-lg-4 col-xl-4 pricing-table">
                                                <div class="pricing-table__inner">
                                                    <div class="pricing-table__header">
                                                        <h6 class="sub-title">Professional</h6>
                                                        <div class="pricing-table__image">
                                                            <img src="/web-dev/assets/images/icons/mitech-pricing-box-icon-03-90x90.webp" class="img-fluid" alt="">
                                                        </div>
                                                        <div class="pricing-table__price-wrap">
                                                            <h6 class="currency">$</h6>
                                                            <h6 class="price">29</h6>
                                                            <h6 class="period">/mo</h6>
                                                        </div>
                                                    </div>
                                                    <div class="pricing-table__body">
                                                        <div class="pricing-table__footer">
                                                            <a href="#" class="ht-btn ht-btn-md ht-btn--outline">Get started</a>
                                                        </div>
                                                        <ul class="pricing-table__list text-left">
                                                            <li>10 projects</li>
                                                            <li>Power And Predictive Dialing </li>
                                                            <li>Quality &amp; Customer Experience </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="year-tab" role="tabpanel">
        
                                        <div class="row pricing-table-one">
                                            <div class="col-12 col-md-6 col-lg-4 col-xl-4 pricing-table">
                                                <div class="pricing-table__inner">
                                                    <div class="pricing-table__header">
                                                        <h6 class="sub-title">Basic</h6>
                                                        <div class="pricing-table__image">
                                                            <img src="/web-dev/assets/images/icons/mitech-pricing-box-icon-01-90x90.webp" class="img-fluid" alt="">
                                                        </div>
                                                        <div class="pricing-table__price-wrap">
                                                            <h6 class="currency">$</h6>
                                                            <h6 class="price">199</h6>
                                                            <h6 class="period">/mo</h6>
                                                        </div>
                                                    </div>
                                                    <div class="pricing-table__body">
                                                        <div class="pricing-table__footer">
                                                            <a href="#" class="ht-btn ht-btn-md ht-btn--outline">Get started</a>
                                                        </div>
                                                        <ul class="pricing-table__list text-left">
                                                            <li>03 projects</li>
                                                            <li>Quality &amp; Customer Experience</li>
                                                            <li><span class="featured">Try for free, forever!</span></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6 col-lg-4 col-xl-4 pricing-table pricing-table--popular">
                                                <div class="pricing-table__inner">
                                                    <div class="pricing-table__feature-mark">
                                                        <span>Popular Choice</span>
                                                    </div>
                                                    <div class="pricing-table__header">
                                                        <h6 class="sub-title">Professional</h6>
                                                        <div class="pricing-table__image">
                                                            <img src="/web-dev/assets/images/icons/mitech-pricing-box-icon-02-88x88.webp" class="img-fluid" alt="">
                                                        </div>
                                                        <div class="pricing-table__price-wrap">
                                                            <h6 class="currency">$</h6>
                                                            <h6 class="price">599</h6>
                                                            <h6 class="period">/mo</h6>
                                                        </div>
                                                    </div>
                                                    <div class="pricing-table__body">
                                                        <div class="pricing-table__footer">
                                                            <a href="#" class="ht-btn  ht-btn-md ">Get started</a>
                                                        </div>
                                                        <ul class="pricing-table__list text-left">
                                                            <li>Unlimited project</li>
                                                            <li>Power And Predictive Dialing</li>
                                                            <li>Quality &amp; Customer Experience</li>
                                                            <li>24/7 phone and email support</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6 col-lg-4 col-xl-4 pricing-table">
                                                <div class="pricing-table__inner">
                                                    <div class="pricing-table__header">
                                                        <h6 class="sub-title">Professional</h6>
                                                        <div class="pricing-table__image">
                                                            <img src="/web-dev/assets/images/icons/mitech-pricing-box-icon-03-90x90.webp" class="img-fluid" alt="">
                                                        </div>
                                                        <div class="pricing-table__price-wrap">
                                                            <h6 class="currency">$</h6>
                                                            <h6 class="price">299</h6>
                                                            <h6 class="period">/mo</h6>
                                                        </div>
                                                    </div>
                                                    <div class="pricing-table__body">
                                                        <div class="pricing-table__footer">
                                                            <a href="#" class="ht-btn ht-btn-md ht-btn--outline">Get started</a>
                                                        </div>
                                                        <ul class="pricing-table__list text-left">
                                                            <li>10 projects</li>
                                                            <li>Power And Predictive Dialing </li>
                                                            <li>Quality &amp; Customer Experience </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--========= Pricing Table Area End ==========-->
            <!--===========  Projects wrapper End =============-->
            <!--=========== fun fact Wrapper Start ==========-->
            <div class="fun-fact-wrapper bg-theme-default section-space--pb_30 section-space--pt_60" id="testimoninal">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 col-sm-6 wow move-up">
                            <div class="fun-fact--two text-center">
                                <div class="fun-fact__count counter">120</div>
                                <h6 class="fun-fact__text">Happy clients</h6>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 wow move-up">
                            <div class="fun-fact--two text-center">
                                <div class="fun-fact__count counter">32</div>
                                <h6 class="fun-fact__text">Finished projects</h6>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 wow move-up">
                            <div class="fun-fact--two text-center">
                                <div class="fun-fact__count counter">73</div>
                                <h6 class="fun-fact__text">Skilled Experts</h6>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 wow move-up">
                            <div class="fun-fact--two text-center">
                                <div class="fun-fact__count counter">318</div>
                                <h6 class="fun-fact__text">Media Posts</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--=========== fun fact Wrapper End ==========-->
            <!--====================  testimonial section ====================-->
            <div class="testimonial-slider-area bg-gray section-space--ptb_100">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-title-wrap text-center section-space--mb_40">
                                <h6 class="section-sub-title mb-20">Testimonials</h6>
                                <h3 class="heading">What do people praise about <span class="text-color-primary"> Harzeno?</span></h3>
                            </div>
                            <div class="testimonial-slider">
                                <div class="swiper-container testimonial-slider__container">
                                    <div class="swiper-wrapper testimonial-slider__wrapper">
                                        <div class="swiper-slide">
                                            <div class="testimonial-slider__one wow move-up">

                                                <div class="testimonial-slider--info">
                                                    <div class="testimonial-slider__media">
                                                        <img src="/web-dev/assets/images/testimonial/Harzeno-testimonial-avata-02-90x90.webp" class="img-fluid" alt="">
                                                    </div>

                                                    <div class="testimonial-slider__author">
                                                        <div class="testimonial-rating">
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                        </div>
                                                        <div class="author-info">
                                                            <h6 class="name">Abbie Ferguson</h6>
                                                            <span class="designation">Marketing</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="testimonial-slider__text">I’ve been working with over 35 IT companies on more than 200 projects of our company, but @Harzeno is one of the most impressive to me.</div>

                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="testimonial-slider__one wow move-up">

                                                <div class="testimonial-slider--info">
                                                    <div class="testimonial-slider__media">
                                                        <img src="/web-dev/assets/images/testimonial/Harzeno-testimonial-avata-03-90x90.webp" class="img-fluid" alt="">
                                                    </div>

                                                    <div class="testimonial-slider__author">
                                                        <div class="testimonial-rating">
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                        </div>
                                                        <div class="author-info">
                                                            <h6 class="name">Monica Blews</h6>
                                                            <span class="designation">Web designer</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="testimonial-slider__text">I’ve been working with over 35 IT companies on more than 200 projects of our company, but @Harzeno is one of the most impressive to me.</div>

                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="testimonial-slider__one wow move-up">

                                                <div class="testimonial-slider--info">
                                                    <div class="testimonial-slider__media">
                                                        <img src="/web-dev/assets/images/testimonial/Harzeno-testimonial-avata-04-90x90.webp" class="img-fluid" alt="">
                                                    </div>

                                                    <div class="testimonial-slider__author">
                                                        <div class="testimonial-rating">
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                        </div>
                                                        <div class="author-info">
                                                            <h6 class="name">Abbie Ferguson</h6>
                                                            <span class="designation">WEB DESIGNER</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="testimonial-slider__text">I’ve been working with over 35 IT companies on more than 200 projects of our company, but @Harzeno is one of the most impressive to me.</div>

                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="testimonial-slider__one wow move-up">

                                                <div class="testimonial-slider--info">
                                                    <div class="testimonial-slider__media">
                                                        <img src="/web-dev/assets/images/testimonial/Harzeno-testimonial-avata-01-90x90.webp" class="img-fluid" alt="">
                                                    </div>

                                                    <div class="testimonial-slider__author">
                                                        <div class="testimonial-rating">
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                        </div>
                                                        <div class="author-info">
                                                            <h6 class="name">Abbie Ferguson</h6>
                                                            <span class="designation">WEB DESIGNER</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="testimonial-slider__text">I’ve been working with over 35 IT companies on more than 200 projects of our company, but @Harzeno is one of the most impressive to me.</div>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-pagination swiper-pagination-t01 section-space--mt_30"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--====================  End of testimonial section  ====================-->
   <!--====================  Conact us Section Start ====================-->
   <div class="contact-us-section-wrappaer section-space--pt_100 section-space--pb_70" id="contactus">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-lg-6">
                <div class="conact-us-wrap-one mb-30">
                    <h3 class="heading">To make requests for <br>further information, <br><span class="text-color-primary">contact us</span> via our social channels. </h3>
                    <div class="sub-heading">We just need a couple of hours! <br> No more than 2 working days since receiving your issue ticket.</div>
                </div>
            </div>

            <div class="col-lg-6 col-lg-6">
                <div class="contact-form-wrap">

                    <!-- <form id="contact-form" action="http://whizthemes.com/mail-php/jowel/mitech/php/mail.php" method="post"> -->
                    <form id="contact-form" action="/web-dev/assets/php/mail.php" method="post">
                        <div class="contact-form">
                            <div class="contact-input">
                                <div class="contact-inner">
                                    <input name="con_name" type="text" placeholder="Name *" required>
                                </div>
                                <div class="contact-inner">
                                    <input name="con_email" type="email" placeholder="Email *" required>
                                </div>
                            </div>
                            <div class="contact-inner">
                                <input name="con_subject" type="text" placeholder="Subject *" required>
                            </div>
                            <div class="contact-inner contact-message">
                                <textarea name="con_message" placeholder="Please describe what you need." required></textarea>
                            </div>
                            <div class="submit-btn mt-20">
                                <button class="ht-btn ht-btn-md" type="submit">Send message</button>
                                <p class="form-messege"></p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!--====================  Conact us Section End  ====================-->

    <!--====================  Conact us info Start ====================-->
    <div class="contact-us-info-wrappaer section-space--pb_100 cta-bg-image_two" style="padding-top: 100px;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 col-md-6">
                    <div class="conact-info-wrap mt-30">
                        <h5 class="heading mb-20">San Francisco</h5>
                        <ul class="conact-info__list">
                            <li>58 Howard Street #2 San Francisco, CA 941</li>
                            <li><a href="#" class="hover-style-link text-color-primary">contact.sanfrancisco@Harzeno.com</a></li>
                            <li><a href="#" class="hover-style-link text-black font-weight--bold">(+68)1221 09876</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="conact-info-wrap mt-30">
                        <h5 class="heading mb-20">New York</h5>
                        <ul class="conact-info__list">
                            <li>58 Howard Street #14 New York</li>
                            <li><a href="#" class="hover-style-link text-color-primary">contact.newyork@Harzeno.com</a></li>
                            <li><a href="#" class="hover-style-link text-black font-weight--bold">(+47)1221 09878</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="conact-info-wrap mt-30">
                        <h5 class="heading mb-20">Russia</h5>
                        <ul class="conact-info__list">
                            <li>The Courtyard Building 11 Curtain Road, Russia</li>
                            <li><a href="#" class="hover-style-link text-color-primary">contact.russia@Harzeno.com</a></li>
                            <li><a href="#" class="hover-style-link text-black font-weight--bold">(+53)1221 09877</a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!--====================  Conact us info End  ====================-->




        </div>

        <!--====================  footer area ====================-->
        <div class="footer-area-wrapper bg-gray">
            <div class="footer-copyright-area section-space--pb_30">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-6 text-center text-md-start">
                            <span class="copyright-text">&copy; 2024 Harzeno. <a href="#home">All Rights Reserved.</a></span>
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                            <ul class="list ht-social-networks solid-rounded-icon">

                                <li class="item">
                                    <a href="https://twitter.com" target="_blank" aria-label="Twitter" class="social-link hint--bounce hint--top hint--primary">
                                        <i class="fab fa-twitter link-icon"></i>
                                    </a>
                                </li>
                                <li class="item">
                                    <a href="https://facebook.com" target="_blank" aria-label="Facebook" class="social-link hint--bounce hint--top hint--primary">
                                        <i class="fab fa-facebook-f link-icon"></i>
                                    </a>
                                </li>
                                <li class="item">
                                    <a href="https://instagram.com" target="_blank" aria-label="Instagram" class="social-link hint--bounce hint--top hint--primary">
                                        <i class="fab fa-instagram link-icon"></i>
                                    </a>
                                </li>
                                <li class="item">
                                    <a href="https://linkedin.com" target="_blank" aria-label="Linkedin" class="social-link hint--bounce hint--top hint--primary">
                                        <i class="fab fa-linkedin link-icon"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--====================  End of footer area  ====================-->





        <style>
            .whatsapp-button {
                position: fixed;
                bottom: 60px;
                left: 20px;
                z-index: 1000;
            }
        </style>
        
        <a href="https://wa.me/12345678900" class="btn btn-success whatsapp-button" target="_blank">
            <i class="bi bi-whatsapp"></i> 
        </a>








    </div>
    <!--====================  scroll top ====================-->
    <a href="#" class="scroll-top" id="scroll-top">
        <i class="arrow-top fas fa-chevron-up"></i>
        <i class="arrow-bottom fas fa-chevron-up"></i>
    </a>
    <!--====================  End of scroll top  ====================-->
    <!-- Start Toolbar -->
    <div class="demo-option-container">
   
        <!-- Start Quick Link -->
        <div class="demo-option-wrapper">
            <div class="demo-panel-header">
                <div class="title">
                    <h6 class="heading mt-30">IT Solutions Harzeno - Technology, IT Solutions & Services Html5 Template</h6>
                </div>

            
            </div>
            <div class="demo-quick-option-list">
                <a class="link hint--bounce hint--black hint--top hint--dark" href="index-appointment.html" aria-label="Appointment">
                    <img class="img-fluid" src="/web-dev/assets/images/demo-images/home-01.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="index-infotechno.html" aria-label="Infotechno">
                    <img class="img-fluid" src="/web-dev/assets/images/demo-images/home-02.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="index-processing.html" aria-label="Processing">
                    <img class="img-fluid" src="/web-dev/assets/images/demo-images/home-03.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="index-services.html" aria-label="Services">
                    <img class="img-fluid" src="/web-dev/assets/images/demo-images/home-04.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="index-resolutions.html" aria-label="Resolutions">
                    <img class="img-fluid" src="/web-dev/assets/images/demo-images/home-05.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="index-cybersecurity.html" aria-label="Cybersecurity">
                    <img class="img-fluid" src="/web-dev/assets/images/demo-images/home-06.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="index-modern-it-company.html" aria-label="Modern IT Company">
                    <img class="img-fluid" src="/web-dev/assets/images/demo-images/modern-it-company.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="index-machine-learning.html" aria-label="Machine Learning">
                    <img class="img-fluid" src="/web-dev/assets/images/demo-images/machine-learning.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="index-software-innovation.html" aria-label="Software Innovation">
                    <img class="img-fluid" src="/web-dev/assets/images/demo-images/software-innovation.webp" alt="Images">
                </a>
            </div>
        </div>
        <!-- End Quick Link -->
    </div>
    <!-- End Toolbar -->

    <!--====================  mobile menu overlay ====================-->
    <div class="mobile-menu-overlay" id="mobile-menu-overlay">
        <div class="mobile-menu-overlay__inner">
            <div class="mobile-menu-overlay__header">
                <div class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col-md-6 col-8">
                            <!-- logo -->
                            <div class="logo">
                                <a href="index.html">
                                    <img src="/web-dev/assets/images/logo/hLogo.png" class="img-fluid" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6 col-4">
                            <!-- mobile menu content -->
                            <div class="mobile-menu-content text-end">
                                <span class="mobile-navigation-close-icon" id="mobile-menu-close-trigger"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mobile-menu-overlay__body">
                <nav class="offcanvas-navigation">
                    <ul>
                        <li>
                            <a href="#home"><span>Home</span></a>
                        </li>
                        <li>
                            <a href="#aboutus"><span>About Us</span></a>
                        </li>
                        <li>
                            <a href="#portfolio"><span>Portfolio</span></a>
                        </li>
                        <li>
                            <a href="#ourteam"><span>Our Team</span></a>
                        </li>
                        <li>
                            <a href="#pricing"><span>Our Pricing</span></a>
                        </li>
                        <li>
                            <a href="#testimoninal"><span>Testimonials</span></a>
                        </li>
                        <li>
                            <a href="#contactus"><span>Contact Us</span></a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
    <!--====================  End of mobile menu overlay  ====================-->





    <!-- JS
    ============================================ -->
    <!-- Modernizer JS -->
    <script src="/web-dev/assets/js/vendor/modernizr-2.8.3.min.js"></script>

    <!-- jQuery JS -->
    <script src="/web-dev/assets/js/vendor/jquery-3.5.1.min.js"></script>
    <script src="/web-dev/assets/js/vendor/jquery-migrate-3.3.0.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="/web-dev/assets/js/vendor/bootstrap.min.js"></script>

    <!-- Plugins JS (Please remove the comment from below plugins.min.js for better website load performance and remove plugin js files from avobe) -->

    <script src="/web-dev/assets/js/plugins/plugins.min.js"></script>

    <!-- Main JS -->
    <script src="/web-dev/assets/js/main.js"></script>

</body>

</html><?php /**PATH /Applications/Laravel Projects/self/harzeno/resources/views/website-application-development/index.blade.php ENDPATH**/ ?>