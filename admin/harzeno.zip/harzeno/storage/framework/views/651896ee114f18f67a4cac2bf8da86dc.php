<!DOCTYPE html>
<html class="no-js" lang="zxx" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>About Us</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Website Development, App Development">
    <!-- Favicon -->
    <link rel="icon" href="assets/images/fav.png">

    <!-- CSS
        ============================================ -->

           <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <!-- Font Family CSS -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet">

    <!-- Vendor & Plugins CSS (Please remove the comment from below vendor.min.css & plugins.min.css for better website load performance and remove css files from avobe) -->

    <link rel="stylesheet" href="assets/css/vendor/vendor.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plugins.min.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <div class="preloader-activate preloader-active open_tm_preloader">
        <div class="preloader-area-wrap">
            <div class="spinner d-flex justify-content-center align-items-center h-100">
                <div class="bounce1"></div>
                <div class="bounce2"></div>
                <div class="bounce3"></div>
            </div>
        </div>
    </div>


    <!--====================  header area ====================-->
    <div class="header-area">

        <!-- Header Top Wrap Start -->
        <div class="header-top-wrap border-bottom">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <p class="text-center top-message"><a href="#">Now Hiring:</a> Are you a driven and motivated 1st Line IT Support Engineer?</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Header Top Wrap End -->

        <div class="header-bottom-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header position-relative">
                            <!-- brand logo -->
                            <div class="header__logo top-logo">
                                <a href="index.html">
                                    <img src="assets/images/logo/hLogo.png" aria-label="Harzeno Logo" width="160" height="48" class="img-fluid" alt="">
                                </a>
                            </div>

                            <div class="header-right flexible-image-slider-wrap">

                                <div class="header-right-inner" id="hidden-icon-wrapper">
                                    <!-- Header Search Form -->
                                    <div class="header-search-form d-md-none d-block">
                                        <form action="#" class="search-form-top">
                                            <input class="search-field" type="text" placeholder="Search…">
                                            <button class="search-submit">
                                                <i class="search-btn-icon fa fa-search"></i>
                                            </button>
                                        </form>
                                    </div>

                                    <!-- Header Top Info -->
                                    <div class="swiper-container header-top-info-slider-werap top-info-slider__container">
                                        <div class="swiper-wrapper header-top-info-inner default-color">
                                            <div class="swiper-slide">
                                                <div class="info-item">
                                                    <div class="info-icon">
                                                        <span class="fa fa-phone"></span>
                                                    </div>
                                                    <div class="info-content">
                                                        <h6 class="info-title">0122 8899900</h6>
                                                        <div class="info-sub-title">Info@example.com</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="info-item">
                                                    <div class="info-icon">
                                                        <span class="fa fa-map-marker-alt"></span>
                                                    </div>
                                                    <div class="info-content">
                                                        <h6 class="info-title">219 Amara Fort Apt. 394</h6>
                                                        <div class="info-sub-title">New York, NY 941</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="info-item">
                                                    <div class="info-icon">
                                                        <span class="fa fa-clock"></span>
                                                    </div>
                                                    <div class="info-content">
                                                        <h6 class="info-title">8:00AM - 6:00PM</h6>
                                                        <div class="info-sub-title">Monday to Saturday</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="info-item">
                                                    <div class="info-icon">
                                                        <span class="fas fa-comment-alt"></span>
                                                    </div>
                                                    <div class="info-content">
                                                        <h6 class="info-title">Online 24/7</h6>
                                                        <div class="info-sub-title">+122 123 4567</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Header Social Networks -->
                                    <div class="header-social-networks style-icons">
                                        <div class="inner">
                                            <a class=" social-link hint--black hint--bottom-left" aria-label="Twitter" href="#" data-hover="Twitter" target="_blank">
                                                <i class="social-icon fab fa-twitter"></i>
                                            </a>
                                            <a class=" social-link hint--black hint--bottom-left" aria-label="Facebook" href="#" data-hover="Facebook" target="_blank">
                                                <i class="social-icon fab fa-facebook-f"></i>
                                            </a>
                                            <a class=" social-link hint--black hint--bottom-left" aria-label="Instagram" href="#" data-hover="Instagram" target="_blank">
                                                <i class="social-icon fab fa-instagram"></i>
                                            </a>
                                            <a class=" social-link hint--black hint--bottom-left" aria-label="Linkedin" href="#" data-hover="Linkedin" target="_blank">
                                                <i class="social-icon fab fa-linkedin"></i>
                                            </a>
                                        </div>
                                    </div>

                                </div>
                                <!-- mobile menu -->
                                <div class="mobile-navigation-icon d-block d-xl-none" id="mobile-menu-trigger">
                                    <i></i>
                                </div>
                                <!-- hidden icons menu -->
                                <div class="hidden-icons-menu d-block d-md-none" id="hidden-icon-trigger">
                                    <a href="javascript:void(0)">
                                        <i class="far fa-ellipsis-h-alt"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <style>
                .header-bottom-wrap1 {
              background: linear-gradient(90deg, #000000 10%, #803494 90%);
            }
            </style>
            <div class="header-bottom-wrap header-bottom-wrap1 bg-theme-default d-md-block d-none header-sticky">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="header-bottom-inner position-relative">
                                <div class="header-bottom-left-wrap">
                                    <!-- navigation menu -->
                                    <div class="header__navigation d-none d-xl-block">
                                        <nav class="navigation-menu navigation-menu--text_white">

                                            <ul>
                                                <li>
                                                    <a href="index.html"><span>Home</span></a>
                                                </li>
                                                <li>
                                                    <a href="aboutus.html"><span>About Us</span></a>
                                                </li>
                                                <li class="has-children has-children--multilevel-submenu">
                                                    <a href="services.html"><span>Our Services</span></a>
                                                    <ul class="submenu">
                                                        <li><a href="customsoftwaredevelopment.html"><span>Custom Software Development</span></a></li>
                                                        <li><a href="appdevelopment.html"><span>Mobile App Development</span></a></li>
                                                        <li><a href="websitedevelopment.html"><span>Website Development</span></a></li>
                                                        <li><a href="aidevelopment.html"><span>AI Development</span></a></li>
                                                        <li><a href="chatbots.html"><span>AI Chatbot Development</span></a></li>
                                                        
                                                 <li><a href="gamedevelopment.html"><span>Game Development</span></a></li>
                                                        <li><a href="rpa.html"><span>Robotic Process Automation (RPA)</span></a></li>    
                                                    </ul>
                                                </li>
                                                <li>
                                                    <a href="portfolio.html"><span>Portfolio</span></a>
                                                </li>
                                                <li>
                                                    <a href="contactus.html"><span>Contact Us</span></a>
                                                </li>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <!--====================  End of header area  ====================-->

    </div>


    <div id="main-wrapper">
        <div class="site-wrapper-reveal">
            <div class="about-banner-wrap banner-space about-banner">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 m-auto">
                            <div class="about-banner-content text-center">
                                <h1 class="mb-15 text-white">About Us</h1> 
                                <h6 class="text-white">Home / About Us</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--===========  feature-large-images-wrapper  Start =============-->
            <div class="feature-large-images-wrapper section-space--ptb_100">
                <div class="container">

                    <div class="row">
                        <div class="col-lg-12">
                            <!-- section-title-wrap Start -->
                            <div class="section-title-wrap text-center section-space--mb_60">
                                <h6 class="section-sub-title mb-20">Our company</h6>
                                <h3 class="heading">We run all kinds of IT services that <br> vow your <span class="text-color-primary"> success</span></h3>
                            </div>
                            <!-- section-title-wrap Start -->
                        </div>
                    </div>

                    <div class="cybersecurity-about-box section-space--pb_70">
                        <div class="row">
                            <div class="col-lg-4 offset-lg-1">
                                <div class="modern-number-01">
                                    <h2 class="heading  me-5"><span class="mark-text">38</span>Years’ Experience in IT</h2>
                                    <h6 class="heading mt-30">More About Our Success Stories</h6>
                                </div>
                            </div>

                            <div class="col-lg-5 offset-lg-1">
                                <div class="cybersecurity-about-text">
                                    <div class="text">Harzeno specializes in technological and IT-related services such as product engineering, warranty management, building cloud, infrastructure, network, etc. We put a strong focus on the needs of your business to figure out solutions that best fits your demand and nail it.</div>
                                    <div class="button-text">
                                        <a href="contactus.html" class="btn-text">
                                            Contact Now
                                            <span class="button-icon ml-1">
                                    <i class="fas fa-arrow-right"></i>
                                </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-12">
                            <div class="feature-images__six">
                                <div class="row">
                                    <div class="col-lg-4 col-md-6 wow move-up">
                                        <!-- ht-box-icon Start -->
                                        <div class="ht-box-images style-06">
                                            <div class="image-box-wrap">
                                                <div class="box-image">
                                                    <div class="default-image">
                                                        <img class="img-fulid" src="assets/images/icons/innovation.png" alt="">
                                                    </div>
                                                </div>
                                                <div class="content">
                                                    <h5 class="heading">What we can do?</h5>
                                                    <div class="text">We put a strong focus on the needs of your business to figure out solutions that best fits your demand and nail it.
                                                    </div>
                                                    <a href="contactus.html" class="box-images-arrow">
                                                        <span class="button-text">Contact Now</span>
                                                        <i class="fas fa-arrow-right"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ht-box-icon End -->
                                    </div>
                                    <div class="col-lg-4 col-md-6 wow move-up">
                                        <!-- ht-box-icon Start -->
                                        <div class="ht-box-images style-06">
                                            <div class="image-box-wrap">
                                                <div class="box-image">
                                                    <div class="default-image">
                                                        <img class="img-fulid" src="assets/images/icons/expert team2.png" alt="">
                                                    </div>
                                                </div>
                                                <div class="content">
                                                    <h5 class="heading">Become our partners?</h5>
                                                    <div class="text">Our preventive and progressive approach will help you take the lead while addressing possible threats in managing data.
                                                    </div>
                                                    <a href="contactus.html" class="box-images-arrow">
                                                        <span class="button-text">Contact Now</span>
                                                        <i class="fas fa-arrow-right"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ht-box-icon End -->
                                    </div>
                                    <div class="col-lg-4 col-md-6 wow move-up">
                                        <!-- ht-box-icon Start -->
                                        <div class="ht-box-images style-06">
                                            <div class="image-box-wrap">
                                                <div class="box-image">
                                                    <div class="default-image">
                                                        <img class="img-fulid" src="assets/images/icons/multiplayer game.png" alt="">
                                                    </div>
                                                </div>
                                                <div class="content">
                                                    <h5 class="heading">Need a hand?</h5>
                                                    <div class="text">Our support team is available 24/7 a day, 7 days a week and can get ready for solving any of your situational rising problems.
                                                    </div>
                                                    <a href="contactus.html" class="box-images-arrow">
                                                        <span class="button-text">Contact Now</span>
                                                        <i class="fas fa-arrow-right"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ht-box-icon End -->
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <!--===========  feature-large-images-wrapper  End =============-->



            <!--========= About Delivering Wrapper Start ===========-->
            <div class="about-delivering-wrapper section-space--ptb_100">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-title-wrap text-center section-space--mb_20">
                                <h3 class="heading">We excel in delivering <br>optimal solutions.</h3>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="delivering-optimal-wrap">
                                <div class="list-item">
                                    <div class="marker"></div>
                                    <div class="title-wrap">
                                        <h5 class="title"> Warranty Management IT </h5>
                                        <div class="desc">Our service offerings enhance customer experience throughout secure &amp; highly functional end-to-end warranty management. </div>
                                    </div>
                                </div>
                                <div class="list-item">
                                    <div class="marker"></div>
                                    <div class="title-wrap">
                                        <h5 class="title"> Quality Control System </h5>
                                        <div class="desc">It's more than a responsibility but a guarantee from us to gain customer trust with highly reliable quality control system. </div>
                                    </div>
                                </div>
                                <div class="list-item">
                                    <div class="marker"></div>
                                    <div class="title-wrap">
                                        <h5 class="title">Highly Professional Staffs </h5>
                                        <div class="desc">Having obtained the official & formal training in IT technology and technical fields, our staffs know more than what they show. </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="delivering-optimal-wrap">
                                <div class="list-item">
                                    <div class="marker"></div>
                                    <div class="title-wrap">
                                        <h5 class="title">Product Engineering & Services </h5>
                                        <div class="desc">Develop and propose product improvements through periodical and accurate testing, repairing & refining every version. </div>
                                    </div>
                                </div>
                                <div class="list-item">
                                    <div class="marker"></div>
                                    <div class="title-wrap">
                                        <h5 class="title">Infrastructure Integration Technology </h5>
                                        <div class="desc">At Harzeno, we have a holistic and integrated approach towards core modernization to experience technological evolution. </div>
                                    </div>
                                </div>
                                <div class="list-item">
                                    <div class="marker"></div>
                                    <div class="title-wrap">
                                        <h5 class="title">Information Security Management </h5>
                                        <div class="desc">Information security has been a rising issue lately due to a series of scandals from big companies, rest assured, we're here. </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--=========== fun fact Wrapper Start ==========-->
            <div class="fun-fact-wrapper bg-theme-default section-space--pb_30 section-space--pt_60">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 col-sm-6 wow move-up">
                            <div class="fun-fact--two text-center">
                                <div class="fun-fact__count counter">120</div>
                                <h6 class="fun-fact__text">Happy clients</h6>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 wow move-up">
                            <div class="fun-fact--two text-center">
                                <div class="fun-fact__count counter">32</div>
                                <h6 class="fun-fact__text">Finished projects</h6>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 wow move-up">
                            <div class="fun-fact--two text-center">
                                <div class="fun-fact__count counter">73</div>
                                <h6 class="fun-fact__text">Skilled Experts</h6>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 wow move-up">
                            <div class="fun-fact--two text-center">
                                <div class="fun-fact__count counter">318</div>
                                <h6 class="fun-fact__text">Media Posts</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--=========== fun fact Wrapper End ==========-->
            <!--====================  testimonial section ====================-->
            <div class="testimonial-slider-area section-space--pt_100">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-title-wrap text-center section-space--mb_40">
                                <h6 class="section-sub-title mb-20">Testimonials</h6>
                                <h3 class="heading">What do people praise about <span class="text-color-primary"> Harzeno?</span></h3>
                            </div>
                            <div class="testimonial-slider">
                                <div class="swiper-container testimonial-slider__container">
                                    <div class="swiper-wrapper testimonial-slider__wrapper">
                                        <div class="swiper-slide">
                                            <div class="testimonial-slider__one wow move-up">

                                                <div class="testimonial-slider--info">
                                                    <div class="testimonial-slider__media">
                                                        <img src="assets/images/testimonial/Harzeno-testimonial-avata-02-90x90.webp" class="img-fluid" alt="">
                                                    </div>

                                                    <div class="testimonial-slider__author">
                                                        <div class="testimonial-rating">
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                        </div>
                                                        <div class="author-info">
                                                            <h6 class="name">Abbie Ferguson</h6>
                                                            <span class="designation">Marketing</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="testimonial-slider__text">I’ve been working with over 35 IT companies on more than 200 projects of our company, but @Harzeno is one of the most impressive to me.</div>

                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="testimonial-slider__one wow move-up">

                                                <div class="testimonial-slider--info">
                                                    <div class="testimonial-slider__media">
                                                        <img src="assets/images/testimonial/Harzeno-testimonial-avata-03-90x90.webp" class="img-fluid" alt="">
                                                    </div>

                                                    <div class="testimonial-slider__author">
                                                        <div class="testimonial-rating">
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                        </div>
                                                        <div class="author-info">
                                                            <h6 class="name">Monica Blews</h6>
                                                            <span class="designation">Web designer</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="testimonial-slider__text">I’ve been working with over 35 IT companies on more than 200 projects of our company, but @Harzeno is one of the most impressive to me.</div>

                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="testimonial-slider__one wow move-up">

                                                <div class="testimonial-slider--info">
                                                    <div class="testimonial-slider__media">
                                                        <img src="assets/images/testimonial/Harzeno-testimonial-avata-04-90x90.webp" class="img-fluid" alt="">
                                                    </div>

                                                    <div class="testimonial-slider__author">
                                                        <div class="testimonial-rating">
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                        </div>
                                                        <div class="author-info">
                                                            <h6 class="name">Abbie Ferguson</h6>
                                                            <span class="designation">WEB DESIGNER</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="testimonial-slider__text">I’ve been working with over 35 IT companies on more than 200 projects of our company, but @Harzeno is one of the most impressive to me.</div>

                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="testimonial-slider__one wow move-up">

                                                <div class="testimonial-slider--info">
                                                    <div class="testimonial-slider__media">
                                                        <img src="assets/images/testimonial/Harzeno-testimonial-avata-01-90x90.webp" class="img-fluid" alt="">
                                                    </div>

                                                    <div class="testimonial-slider__author">
                                                        <div class="testimonial-rating">
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                        </div>
                                                        <div class="author-info">
                                                            <h6 class="name">Abbie Ferguson</h6>
                                                            <span class="designation">WEB DESIGNER</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="testimonial-slider__text">I’ve been working with over 35 IT companies on more than 200 projects of our company, but @Harzeno is one of the most impressive to me.</div>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-pagination swiper-pagination-t01 section-space--mt_30"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--====================  End of testimonial section  ====================-->

            <!--====================  brand logo slider area ====================-->
            <div class="brand-logo-slider-area section-space--ptb_60">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- brand logo slider -->
                            <div class="brand-logo-slider__container-area">
                                <div class="swiper-container brand-logo-slider__container">
                                    <div class="swiper-wrapper brand-logo-slider__one">
                                        <div class="swiper-slide brand-logo brand-logo--slider">
                                            <a href="#">
                                                <div class="brand-logo__image">
                                                    <img src="assets/images/brand/Harzeno-client-logo-01.webp" class="img-fluid" alt="">
                                                </div>
                                                <div class="brand-logo__image-hover">
                                                    <img src="assets/images/brand/Harzeno-client-logo-01-hover.webp" class="img-fluid" alt="">
                                                </div>
                                            </a>
                                        </div>
                                        <div class="swiper-slide brand-logo brand-logo--slider">
                                            <a href="#">
                                                <div class="brand-logo__image">
                                                    <img src="assets/images/brand/Harzeno-client-logo-02.webp" class="img-fluid" alt="">
                                                </div>
                                                <div class="brand-logo__image-hover">
                                                    <img src="assets/images/brand/Harzeno-client-logo-02-hover.webp" class="img-fluid" alt="">
                                                </div>
                                            </a>
                                        </div>
                                        <div class="swiper-slide brand-logo brand-logo--slider">
                                            <a href="#">
                                                <div class="brand-logo__image">
                                                    <img src="assets/images/brand/Harzeno-client-logo-03.webp" class="img-fluid" alt="">
                                                </div>
                                                <div class="brand-logo__image-hover">
                                                    <img src="assets/images/brand/Harzeno-client-logo-03-hover.webp" class="img-fluid" alt="">
                                                </div>
                                            </a>
                                        </div>
                                        <div class="swiper-slide brand-logo brand-logo--slider">
                                            <a href="#">
                                                <div class="brand-logo__image">
                                                    <img src="assets/images/brand/Harzeno-client-logo-04.webp" class="img-fluid" alt="">
                                                </div>
                                                <div class="brand-logo__image-hover">
                                                    <img src="assets/images/brand/Harzeno-client-logo-04-hover.webp" class="img-fluid" alt="">
                                                </div>
                                            </a>
                                        </div>
                                        <div class="swiper-slide brand-logo brand-logo--slider">
                                            <a href="#">
                                                <div class="brand-logo__image">
                                                    <img src="assets/images/brand/Harzeno-client-logo-05.webp" class="img-fluid" alt="">
                                                </div>
                                                <div class="brand-logo__image-hover">
                                                    <img src="assets/images/brand/Harzeno-client-logo-05-hover.webp" class="img-fluid" alt="">
                                                </div>
                                            </a>
                                        </div>
                                        <div class="swiper-slide brand-logo brand-logo--slider">
                                            <a href="#">
                                                <div class="brand-logo__image">
                                                    <img src="assets/images/brand/Harzeno-client-logo-06.webp" class="img-fluid" alt="">
                                                </div>
                                                <div class="brand-logo__image-hover">
                                                    <img src="assets/images/brand/Harzeno-client-logo-06-hover.webp" class="img-fluid" alt="">
                                                </div>
                                            </a>
                                        </div>
                                        <div class="swiper-slide brand-logo brand-logo--slider">
                                            <a href="#">
                                                <div class="brand-logo__image">
                                                    <img src="assets/images/brand/Harzeno-client-logo-07.webp" class="img-fluid" alt="">
                                                </div>
                                                <div class="brand-logo__image-hover">
                                                    <img src="assets/images/brand/Harzeno-client-logo-07-hover.webp" class="img-fluid" alt="">
                                                </div>
                                            </a>
                                        </div>
                                        <div class="swiper-slide brand-logo brand-logo--slider">
                                            <a href="#">
                                                <div class="brand-logo__image">
                                                    <img src="assets/images/brand/Harzeno-client-logo-08.webp" class="img-fluid" alt="">
                                                </div>
                                                <div class="brand-logo__image-hover">
                                                    <img src="assets/images/brand/Harzeno-client-logo-08-hover.webp" class="img-fluid" alt="">
                                                </div>
                                            </a>
                                        </div>
                                        <div class="swiper-slide brand-logo brand-logo--slider">
                                            <a href="#">
                                                <div class="brand-logo__image">
                                                    <img src="assets/images/brand/Harzeno-client-logo-09.webp" class="img-fluid" alt="">
                                                </div>
                                                <div class="brand-logo__image-hover">
                                                    <img src="assets/images/brand/Harzeno-client-logo-09-hover.webp" class="img-fluid" alt="">
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--====================  End of brand logo slider area  ====================-->
            <!--============ Contact Us Area Start =================-->
            <div class="contact-us-area infotechno-contact-us-bg section-space--pt_100">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-7">
                            <div class="image">
                                <img class="img-fluid" src="assets/images/banners/home-cybersecurity-contact-bg-image.webp" alt="">
                            </div>
                        </div>

                        <div class="col-lg-4 ms-auto">
                            <div class="contact-info style-two text-left">

                                <div class="contact-info-title-wrap text-center">
                                    <h3 class="heading  mb-10">4.9/5.0</h3>
                                    <div class="ht-star-rating lg-style">
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                    </div>
                                    <p class="sub-text">by 700+ customers for 3200+ clients</p>
                                </div>

                                <div class="contact-list-item">
                                    <a href="tel:190068668" class="single-contact-list">
                                        <div class="content-wrap">
                                            <div class="content">
                                                <div class="icon">
                                                    <span class="fas fa-phone"></span>
                                                </div>
                                                <div class="main-content">
                                                    <h6 class="heading">Call for advice now!</h6>
                                                    <div class="text">1900 68668</div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                    <a href="mailto:hello@Harzeno.com" class="single-contact-list">
                                        <div class="content-wrap">
                                            <div class="content">
                                                <div class="icon">
                                                    <span class="far fa-envelope"></span>
                                                </div>
                                                <div class="main-content">
                                                    <h6 class="heading">Say hello</h6>
                                                    <div class="text">hello@Harzeno.com</div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--============ Contact Us Area End =================-->

        </div>




        <!--====================  footer area ====================-->
        <div class="footer-area-wrapper bg-gray">
            <div class="footer-area section-space--ptb_80">
                <div class="container">
                    <div class="row footer-widget-wrapper">
                        <div class="col-lg-4 col-md-6 col-sm-6 footer-widget">
                            <div class="footer-widget__logo mb-30">
                                <img src="assets/images/logo/hLogo.png" width="160" height="48" class="img-fluid" alt="">
                            </div>
                            <p>
                                We are creative and professional website designing company in Lahore Pakistan. We are offering the best solutions of web development, logo designing, graphic design, domain registration, web hosting and all IT solutions in Pakistan.
                            </p>
                        </div>
                        <div class="col-lg-2 col-md-4 col-sm-6 footer-widget">
                            <h6 class="footer-widget__title mb-20">About Us</h6>
                            <ul class="footer-widget__list">
                                       <li><a href="index.html" class="hover-style-link">Home</a></li>
                                <li><a href="aboutus.html" class="hover-style-link">About Us</a></li>
                                <li><a href="services.html" class="hover-style-link">Our Services</a></li>
                                <li><a href="portfolio.html" class="hover-style-link">Portfolio</a></li>
                                <li><a href="contactus.html" class="hover-style-link">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-lg-2 col-md-4 col-sm-6 footer-widget">
                            <h6 class="footer-widget__title mb-20">Our Services</h6>
                            <ul class="footer-widget__list">
                               <li><a href="customsoftwaredevelopment.html" class="hover-style-link">Custom Software Development</a></li>
                                <li><a href="appdevelopment.html" class="hover-style-link">Mobile App Development</a></li>
                                <li><a href="websitedevelopment.html" class="hover-style-link">Website Development</a></li>
                                <li><a href="aidevelopment.html" class="hover-style-link">AI Development</a></li>
                                <li><a href="chatbots.html" class="hover-style-link">AI Chatbot Development</a></li>
                                <li><a href="gamedevelopment.html" class="hover-style-link">Game Development</a></li>
                                <li><a href="rpa.html" class="hover-style-link">Robotic Process Automation (RPA)</a></li>
                            </ul>
                        </div>
              
                        <div class="col-lg-2 col-md-4 col-sm-6 footer-widget">
                            <h6 class="footer-widget__title mb-20">Industries</h6>
                            <ul class="footer-widget__list">
                                <li><a href="#" class="hover-style-link">Education Consultants</a></li>
                                <li><a href="#" class="hover-style-link">Classified Website</a></li>
                                <li><a href="contactus.html" class="hover-style-link">Ngo Website</a></li>
                                <li><a href="#" class="hover-style-link">Travel Agents</a></li>
                                <li><a href="#" class="hover-style-link">Textile Website</a></li>
                                <li><a href="#" class="hover-style-link">Fans Website</a></li>
                            </ul>
                        </div>
                        <div class="col-lg-2 col-md-4 col-sm-6 footer-widget">
                            <h6 class="footer-widget__title mb-20">Contact Us</h6>
                            <ul class="footer-widget__list">
                                <li><a href="#" class="hover-style-link">
                                    +92 321 888 3377</a></li>
                                <li><a href="#" class="hover-style-link">+92 42 3 519 9468</a></li>
                                <li><a href="contactus.html" class="hover-style-link">harzeno@gmail.com</a></li>
                                <li><a href="#" class="hover-style-link">
                                    Office # 207A, 2nd Floor, Siddique Trade Center, Gulberg Lahore.</a></li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-copyright-area section-space--pb_30">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-6 text-center text-md-start">
                            <span class="copyright-text">&copy; 2024 Harzeno. <a href="#">All Rights Reserved.</a></span>
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                               <a href="privacypolicy.html" target="_blank" aria-label="Privacy Policy" class="social-link hint--bounce hint--top hint--primary">
                                        Privacy Policy
                                    </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--====================  End of footer area  ====================-->












           <style>
            .whatsapp-button {
                position: fixed;
                bottom: 60px;
                left: 20px;
                z-index: 1000;
            }
        </style>
        
        <a href="https://wa.me/12345678900" class="btn btn-success whatsapp-button" target="_blank">
            <i class="bi bi-whatsapp"></i> 
        </a>
        







    </div>
    <!--====================  scroll top ====================-->
    <a href="#" class="scroll-top" id="scroll-top">
        <i class="arrow-top fas fa-chevron-up"></i>
        <i class="arrow-bottom fas fa-chevron-up"></i>
    </a>
    <!--====================  End of scroll top  ====================-->
    <!-- Start Toolbar -->
    <div class="demo-option-container">

        <!-- Start Quick Link -->
        <div class="demo-option-wrapper">
            <div class="demo-panel-header">
                <div class="title">
                    <h6 class="heading mt-30">IT Solutions Harzeno - Technology, IT Solutions & Services Html5 Template</h6>
                </div>

                <div class="panel-btn mt-20">
                    <a class="ht-btn ht-btn-md" href="#"><i class="fa fa-shopping-cart me-2"></i> Buy Now </a>
                </div>
            </div>
            <div class="demo-quick-option-list">
                <a class="link hint--bounce hint--black hint--top hint--dark" href="#" aria-label="Appointment">
                    <img class="img-fluid" src="assets/images/demo-images/home-01.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="#" aria-label="Infotechno">
                    <img class="img-fluid" src="assets/images/demo-images/home-02.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="#" aria-label="Processing">
                    <img class="img-fluid" src="assets/images/demo-images/home-03.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="#" aria-label="Services">
                    <img class="img-fluid" src="assets/images/demo-images/home-04.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="#" aria-label="Resolutions">
                    <img class="img-fluid" src="assets/images/demo-images/home-05.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="#" aria-label="Cybersecurity">
                    <img class="img-fluid" src="assets/images/demo-images/home-06.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="#" aria-label="Modern IT Company">
                    <img class="img-fluid" src="assets/images/demo-images/modern-it-company.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="#" aria-label="Machine Learning">
                    <img class="img-fluid" src="assets/images/demo-images/machine-learning.webp" alt="Images">
                </a>
                <a class="link hint--bounce hint--black hint--top hint--dark" href="#" aria-label="Software Innovation">
                    <img class="img-fluid" src="assets/images/demo-images/software-innovation.webp" alt="Images">
                </a>
            </div>
        </div>
        <!-- End Quick Link -->
    </div>
    <!-- End Toolbar -->

    <!--====================  mobile menu overlay ====================-->
     <div class="mobile-menu-overlay" id="mobile-menu-overlay">
        <div class="mobile-menu-overlay__inner">
            <div class="mobile-menu-overlay__header">
                <div class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col-md-6 col-8">
                            <!-- logo -->
                            <div class="logo">
                                <a href="index.html">
                                    <img src="assets/images/logo/hLogo.png" class="img-fluid" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6 col-4">
                            <!-- mobile menu content -->
                            <div class="mobile-menu-content text-end">
                                <span class="mobile-navigation-close-icon" id="mobile-menu-close-trigger"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mobile-menu-overlay__body">
                <nav class="offcanvas-navigation">
                    <ul>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                                    <a href="aboutus.html"><span>About us</span></a>
                        </li>
                        <li class="has-children">
                            <a href="services.html">Our Services</a>
                            <ul class="sub-menu">
                                <li><a href="customsoftwaredevelopment.html"><span>Custom Software Development</span></a></li>
                                <li><a href="appdevelopment.html"><span>Mobile App Development</span></a></li>
                                <li><a href="websitedevelopment.html"><span>Website Development</span></a></li>
                                <li><a href="aidevelopment.html"><span>AI Development</span></a></li>
                                <li><a href="chatbots.html"><span>AI Chatbot Development</span></a></li>
                                
                                                 <li><a href="gamedevelopment.html"><span>Game Development</span></a></li>
                                <li><a href="rpa.html"><span>Robotic Process Automation (RPA)</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="portfolio.html"><span>Portfolio</span></a>
                </li>
                <li>
                    <a href="contactus.html"><span>Contact Us</span></a>
        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
    <!--====================  End of mobile menu overlay  ====================-->







    <!--====================  search overlay ====================-->
    <div class="search-overlay" id="search-overlay">

        <div class="search-overlay__header">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-md-6 ms-auto col-4">
                        <!-- search content -->
                        <div class="search-content text-end">
                            <span class="mobile-navigation-close-icon" id="search-close-trigger"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="search-overlay__inner">
            <div class="search-overlay__body">
                <div class="search-overlay__form">
                    <form action="#">
                        <input type="text" placeholder="Search">
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--====================  End of search overlay  ====================-->








    <!-- JS
    ============================================ -->
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>

    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.5.1.min.js"></script>
    <script src="assets/js/vendor/jquery-migrate-3.3.0.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>

    <!-- Plugins JS (Please remove the comment from below plugins.min.js for better website load performance and remove plugin js files from avobe) -->

    <script src="assets/js/plugins/plugins.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

</body>

</html><?php /**PATH /Applications/Laravel Projects/self/harzeno/resources/views/aboutus.blade.php ENDPATH**/ ?>